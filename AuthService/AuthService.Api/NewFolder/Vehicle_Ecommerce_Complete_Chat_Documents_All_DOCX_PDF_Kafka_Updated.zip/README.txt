Vehicle Sales & E-commerce Project — Complete Document Bundle (Kafka Updated)
Generated: 2026-10-13

This archive consolidates project-related DOCX and PDF documents found in the working files and project Library.

The SalesOrder Service guide has been updated to include a concrete Kafka/Outbox implementation section:
- Confluent.Kafka package and configuration
- Event envelope and SQL Outbox entity
- Outbox publisher BackgroundService
- Kafka consumer worker and manual offset commits
- Processed-event idempotency table
- PaymentSucceeded event handling example
- DI registration, topic setup, end-to-end verification and reliability checklist

Other documents include initial requirements, architecture, authentication, Item/ItemPrice, price breakup/accessories, Dealer Service, Razorpay Payment Service, Notification Service, and React implementation guides.

Some docs may be DOCX-only or PDF-only if that was the only available source format. Implementation guides are not a single fully wired runnable repository; review integration notes and validate code against your solution.
